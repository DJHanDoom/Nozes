import { GoogleGenAI, Type } from "@google/genai";
import { Project, Entity, Feature, AIConfig } from "../types";

// Helper to generate IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

export const generateKeyFromTopic = async (config: AIConfig): Promise<Project> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const langInstruction = config.language === 'pt' 
    ? "All content (Project Name, Description, Features, States, Entities, Descriptions) MUST be in Portuguese (Brazil)."
    : "All content must be in English.";

  let focusInstruction = "";
  if (config.featureFocus === 'reproductive') {
    focusInstruction = "Focus primarily on reproductive features (e.g., flowers, fruits, seeds, cones, spores, inflorescence).";
  } else if (config.featureFocus === 'vegetative') {
    focusInstruction = "Focus primarily on vegetative features (e.g., leaves, bark, stem, roots, growth habit, phyllo taxis).";
  } else {
    focusInstruction = "Use a balanced mix of vegetative and reproductive features.";
  }

  let speciesImageInstruction = config.includeSpeciesImages 
    ? "For each entity, you MUST provide a valid, public, static URL (e.g., from Wikimedia Commons or reliable CDN) for the `imageUrl` field. Do not leave it empty. If unsure, use a generic placeholder."
    : "Leave `imageUrl` empty for entities.";

  let featureImageInstruction = config.includeFeatureImages
    ? "For each feature, try to provide a generic illustrative image URL in the `imageUrl` field (e.g., diagram or photo of that feature type)."
    : "Leave `imageUrl` empty for features.";

  const systemInstruction = `
    You are an expert taxonomist and biologist. 
    Your task is to create an interactive identification key (matrix key) based strictly on the user's constraints.
    
    Constraints:
    1.  **Language**: ${langInstruction}
    2.  **Topic**: The general subject.
    3.  **Geography**: Restrict entities to this region/biome.
    4.  **Taxonomy**: Restrict to this Family/Genus/Order if specified.
    5.  **Quantity**: Generate exactly or close to the requested number of entities and features.
    6.  **Focus**: ${focusInstruction}
    7.  **Images**: 
        - Species: ${speciesImageInstruction}
        - Features: ${featureImageInstruction}

    Output Requirements:
    1.  List of distinctive features (attributes). Each feature must have 2 or more mutually exclusive states.
    2.  List of entities.
    3.  Matrix: Assign correct states for every feature to every entity.
    4.  **Scientific Accuracy**: Ensure traits are factual.

    The response must be a structured JSON object.
  `;

  const prompt = `
    Create an identification key for: "${config.topic}".
    
    Constraints:
    - Language: ${config.language === 'pt' ? 'Portuguese' : 'English'}
    - Geographic Scope: ${config.geography || "Global"}
    - Taxonomic Context: ${config.taxonomy || "General"}
    - Target Number of Entities: ${config.count}
    - Target Number of Features: ${config.featureCount}
    - Feature Focus: ${config.featureFocus}

    Ensure the features allow for effective separation of these entities.
  `;

  const generateContentWithFallback = async (modelName: string) => {
    try {
      return await ai.models.generateContent({
        model: modelName.trim(),
        contents: prompt,
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              projectName: { type: Type.STRING },
              projectDescription: { type: Type.STRING },
              features: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING, description: "Name of the feature (e.g., 'Wing Color')" },
                    imageUrl: { type: Type.STRING, description: "URL for feature illustration" },
                    states: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING, description: "A state description (e.g., 'Blue')" }
                    }
                  },
                  required: ["name", "states"]
                }
              },
              entities: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    description: { type: Type.STRING },
                    imageUrl: { type: Type.STRING, description: "URL for species image" },
                    traits: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          featureName: { type: Type.STRING, description: "Must match one of the feature names exactly" },
                          stateValue: { type: Type.STRING, description: "Must match one of the state values for that feature exactly" }
                        }
                      }
                    }
                  },
                  required: ["name", "description", "traits"]
                }
              }
            },
            required: ["projectName", "projectDescription", "features", "entities"]
          }
        }
      });
    } catch (error: any) {
      // Check for common 404 errors (model not found)
      if (error.message?.includes("404") || error.message?.includes("NOT_FOUND")) {
        // Fallback to gemini-2.5-flash if the requested model was different
        const fallbackModel = "gemini-2.5-flash";
        if (modelName !== fallbackModel) {
           console.warn(`Model ${modelName} not found, falling back to ${fallbackModel}`);
           return await generateContentWithFallback(fallbackModel);
        }
      }
      throw error;
    }
  };

  try {
    const modelToUse = config.model || "gemini-2.5-flash";
    const response = await generateContentWithFallback(modelToUse);

    const data = JSON.parse(response.text || "{}");
    
    if (!data.projectName) throw new Error("Invalid AI response");

    // Transform AI response to internal data model with IDs
    const features: Feature[] = data.features.map((f: any) => ({
      id: generateId(),
      name: f.name,
      imageUrl: f.imageUrl || "", 
      states: f.states.map((s: string) => ({ id: generateId(), label: s }))
    }));

    const entities: Entity[] = data.entities.map((e: any) => {
      const entityTraits: Record<string, string[]> = {};
      
      e.traits.forEach((t: any) => {
        const feature = features.find(f => f.name === t.featureName);
        if (feature) {
          const state = feature.states.find(s => s.label === t.stateValue);
          if (state) {
            if (!entityTraits[feature.id]) entityTraits[feature.id] = [];
            entityTraits[feature.id].push(state.id);
          }
        }
      });

      return {
        id: generateId(),
        name: e.name,
        description: e.description,
        // Use provided URL, or fallback to placeholder only if requested URL is empty/missing
        imageUrl: e.imageUrl || `https://picsum.photos/seed/${encodeURIComponent(e.name)}/400/300`,
        traits: entityTraits
      };
    });

    return {
      id: generateId(),
      name: data.projectName,
      description: data.projectDescription,
      features,
      entities
    };

  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
};