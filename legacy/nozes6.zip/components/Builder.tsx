import React, { useState, useEffect } from 'react';
import { Project, Entity, Feature, AIConfig, Language, FeatureFocus } from '../types';
import { generateKeyFromTopic } from '../services/geminiService';
import { Wand2, Plus, Trash2, Save, Grid, LayoutList, Box, Loader2, CheckSquare, X, Download, Upload, Image as ImageIcon, FolderOpen, Settings2, Brain } from 'lucide-react';

interface BuilderProps {
  initialProject: Project | null;
  onSave: (project: Project) => void;
  onCancel: () => void;
  language: Language;
  defaultModel: string;
}

type Tab = 'GENERAL' | 'FEATURES' | 'ENTITIES' | 'MATRIX';

const t = {
  en: {
    builder: "Builder",
    aiWizard: "Nuts AI",
    savePlay: "Save & Play",
    exit: "Exit",
    save: "Save",
    open: "Open Saved",
    export: "Export",
    import: "Import",
    general: "General",
    features: "Features",
    entities: "Entities",
    matrix: "Matrix Scoring",
    projectName: "Project Name",
    description: "Description",
    definedFeatures: "Defined Features",
    definedFeaturesDesc: "Define traits and their possible states.",
    addFeature: "Add Feature",
    featureName: "Feature Name",
    imageURL: "Image URL (optional)",
    states: "States",
    addState: "Add State",
    manageEntities: "Entities",
    manageEntitiesDesc: "Manage the taxa included in your key.",
    addEntity: "Add Entity",
    scoringMatrix: "Scoring Matrix",
    scoringMatrixDesc: "Click cells to toggle state association",
    taxaFeatures: "Taxa / Features",
    aiTitle: "Nuts AI Wizard",
    aiDesc: "Describe your target group, and Nuts AI will generate the entities, features, and scoring matrix automatically using Gemini.",
    topic: "Key Topic / Subject",
    topicPlace: "e.g. Freshwater Fishes, Garden Weeds",
    geography: "Geography / Biome",
    taxonomy: "Taxonomy Filter",
    numEntities: "Approx. # of Entities",
    numFeatures: "Approx. # of Features",
    generating: "Nozes IA is thinking... (15-45s)",
    cancel: "Cancel",
    generate: "Generate Key",
    savedMsg: "Project saved to browser storage!",
    errGen: "Failed to generate key. Check console.",
    featureFocus: "Feature Focus",
    focusGeneral: "General",
    focusRepro: "Reproductive (Flowers/Fruits)",
    focusVeg: "Vegetative (Leaves/Stem)",
    options: "Options",
    fetchSpeciesImg: "Fetch Species Images (Beta)",
    fetchFeatureImg: "Fetch Feature Images (Beta)",
    noSaved: "No saved projects.",
    close: "Close"
  },
  pt: {
    builder: "Construtor",
    aiWizard: "Nozes IA",
    savePlay: "Salvar & Testar",
    exit: "Sair",
    save: "Salvar",
    open: "Abrir Salva",
    export: "Exportar",
    import: "Importar",
    general: "Geral",
    features: "Características",
    entities: "Entidades",
    matrix: "Matriz",
    projectName: "Nome do Projeto",
    description: "Descrição",
    definedFeatures: "Características Definidas",
    definedFeaturesDesc: "Defina características e seus estados possíveis.",
    addFeature: "Adicionar Característica",
    featureName: "Nome",
    imageURL: "URL da Imagem (opcional)",
    states: "Estados",
    addState: "Adicionar Estado",
    manageEntities: "Entidades",
    manageEntitiesDesc: "Gerencie os táxons incluídos na chave.",
    addEntity: "Adicionar Entidade",
    scoringMatrix: "Matriz de Pontuação",
    scoringMatrixDesc: "Clique nas células para associar estados",
    taxaFeatures: "Táxons / Características",
    aiTitle: "Assistente Nozes IA",
    aiDesc: "Descreva o grupo alvo, e a Nozes IA gerará as entidades, características e matriz automaticamente usando Gemini.",
    topic: "Tópico / Assunto",
    topicPlace: "ex: Peixes de Água Doce, Ervas Daninhas",
    geography: "Geografia / Bioma",
    taxonomy: "Filtro Taxonômico",
    numEntities: "Aprox. # de Entidades",
    numFeatures: "Aprox. # de Características",
    generating: "Nozes IA está pensando... (15-45s)",
    cancel: "Cancelar",
    generate: "Gerar Chave",
    savedMsg: "Projeto salvo no navegador!",
    errGen: "Falha ao gerar chave. Verifique o console.",
    featureFocus: "Foco das Características",
    focusGeneral: "Geral (Misto)",
    focusRepro: "Reprodutivas (Flores/Frutos)",
    focusVeg: "Vegetativas (Folhas/Caule)",
    options: "Opções",
    fetchSpeciesImg: "Buscar Imagens de Espécies (Beta)",
    fetchFeatureImg: "Buscar Imagens de Características (Beta)",
    noSaved: "Nenhum projeto salvo.",
    close: "Fechar"
  }
};

export const Builder: React.FC<BuilderProps> = ({ initialProject, onSave, onCancel, language, defaultModel }) => {
  const strings = t[language];
  // State
  const [project, setProject] = useState<Project>(initialProject || {
    id: Math.random().toString(36).substr(2, 9),
    name: language === 'pt' ? "Nova Chave" : "New Key",
    description: "",
    features: [],
    entities: []
  });
  const [activeTab, setActiveTab] = useState<Tab>('GENERAL');
  
  // AI Generation State
  const [aiConfig, setAiConfig] = useState<AIConfig>({
    topic: "",
    count: 10,
    featureCount: 5,
    geography: "",
    taxonomy: "",
    language: language,
    featureFocus: 'general',
    includeSpeciesImages: false,
    includeFeatureImages: false,
    model: defaultModel
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);
  const [savedProjects, setSavedProjects] = useState<Project[]>([]);
  const [showLoadModal, setShowLoadModal] = useState(false);

  // Update AI config language when prop changes
  useEffect(() => {
    setAiConfig(prev => ({...prev, language}));
  }, [language]);

  // Update model if defaultModel prop changes
  useEffect(() => {
    setAiConfig(prev => ({...prev, model: defaultModel}));
  }, [defaultModel]);

  useEffect(() => {
    const saved = localStorage.getItem('lucidgen_projects');
    if (saved) {
      try {
        setSavedProjects(JSON.parse(saved));
      } catch (e) { console.error("Failed to load local projects"); }
    }
  }, []);

  // Handlers
  const updateProject = (updates: Partial<Project>) => setProject(p => ({ ...p, ...updates }));

  const saveToLocal = () => {
    const updatedList = [project, ...savedProjects.filter(p => p.id !== project.id)];
    setSavedProjects(updatedList);
    localStorage.setItem('lucidgen_projects', JSON.stringify(updatedList));
    alert(strings.savedMsg);
  };

  const loadFromLocal = (p: Project) => {
    setProject(p);
    setShowLoadModal(false);
  };

  const exportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(project));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `${project.name.replace(/\s+/g, '_')}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  // Import JSON logic remains here for convenience, though main entry is Home
  const importJSON = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (event.target.files && event.target.files[0]) {
      fileReader.readAsText(event.target.files[0], "UTF-8");
      fileReader.onload = e => {
        try {
          const parsed = JSON.parse(e.target?.result as string);
          if (parsed.name && parsed.features && parsed.entities) {
            setProject(parsed);
          } else {
            alert("Invalid project file format.");
          }
        } catch (error) {
          alert("Error parsing JSON file.");
        }
      };
    }
  };

  const handleAiGenerate = async () => {
    if (!aiConfig.topic.trim()) return;
    setIsGenerating(true);
    try {
      const generatedProject = await generateKeyFromTopic(aiConfig);
      setProject(generatedProject);
      setShowAiModal(false);
      setActiveTab('MATRIX'); 
    } catch (e) {
      console.error(e);
      alert(strings.errGen);
    } finally {
      setIsGenerating(false);
    }
  };

  const addFeature = () => {
    const newFeature: Feature = {
      id: Math.random().toString(36).substr(2, 9),
      name: language === 'pt' ? "Nova Característica" : "New Feature",
      imageUrl: "",
      states: [{ id: Math.random().toString(36).substr(2, 9), label: language === 'pt' ? "Estado 1" : "State 1" }]
    };
    setProject(p => ({ ...p, features: [...p.features, newFeature] }));
  };

  const addEntity = () => {
    const newEntity: Entity = {
      id: Math.random().toString(36).substr(2, 9),
      name: language === 'pt' ? "Nova Entidade" : "New Entity",
      description: "...",
      traits: {}
    };
    setProject(p => ({ ...p, entities: [...p.entities, newEntity] }));
  };

  const toggleTrait = (entityId: string, featureId: string, stateId: string) => {
    setProject(p => {
      const entities = p.entities.map(e => {
        if (e.id !== entityId) return e;
        const currentTraits = e.traits[featureId] || [];
        const hasTrait = currentTraits.includes(stateId);
        let newTraits;
        if (hasTrait) {
          newTraits = currentTraits.filter(id => id !== stateId);
        } else {
          newTraits = [...currentTraits, stateId];
        }
        return { ...e, traits: { ...e.traits, [featureId]: newTraits } };
      });
      return { ...p, entities };
    });
  };

  return (
    <div className="flex flex-col h-full bg-white font-sans">
      {/* Builder Header */}
      <div className="border-b px-6 py-3 flex justify-between items-center bg-slate-900 text-white shadow-md z-20">
        <div className="flex items-center gap-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
             <span className="bg-emerald-500 text-xs text-white px-2 py-1 rounded uppercase tracking-wider shadow-sm">{strings.builder}</span>
             <span className="truncate max-w-[200px]">{project.name}</span>
          </h2>
          
          <div className="h-6 w-px bg-slate-700 mx-2"></div>
          
          {/* File Menu (Secondary Access) */}
          <div className="flex items-center gap-1 text-sm">
             <button onClick={saveToLocal} className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-slate-700 rounded transition-colors text-slate-300 hover:text-white" title={strings.save}>
                <Save size={14} /> <span className="hidden sm:inline">{strings.save}</span>
             </button>
             <button onClick={() => setShowLoadModal(true)} className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-slate-700 rounded transition-colors text-slate-300 hover:text-white" title={strings.open}>
                <FolderOpen size={14} /> <span className="hidden sm:inline">{strings.open}</span>
             </button>
             <button onClick={exportJSON} className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-slate-700 rounded transition-colors text-slate-300 hover:text-white" title={strings.export}>
                <Download size={14} /> <span className="hidden sm:inline">{strings.export}</span>
             </button>
             <label className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-slate-700 rounded transition-colors text-slate-300 hover:text-white cursor-pointer" title={strings.import}>
                <Upload size={14} /> <span className="hidden sm:inline">{strings.import}</span>
                <input type="file" accept=".json" onChange={importJSON} className="hidden" />
             </label>
          </div>
        </div>

        <div className="flex gap-3">
          {/* Nozes IA Button */}
          <button 
            onClick={() => setShowAiModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-white rounded-lg transition-all shadow-lg shadow-amber-900/30 text-sm font-bold border border-amber-400/20 group"
          >
            <Brain size={16} className="text-white fill-white/20 group-hover:scale-110 transition-transform" /> {strings.aiWizard}
          </button>

          <button onClick={() => onSave(project)} className="flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-all text-sm font-semibold shadow-lg shadow-emerald-900/30 text-white">
            <Save size={16} /> {strings.savePlay}
          </button>
          <button onClick={onCancel} className="px-4 py-2 text-slate-400 hover:text-white transition-colors text-sm font-medium">
            {strings.exit}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b bg-white px-6">
        {[
          { id: 'GENERAL', label: strings.general, icon: Box },
          { id: 'FEATURES', label: strings.features, icon: LayoutList },
          { id: 'ENTITIES', label: strings.entities, icon: Grid },
          { id: 'MATRIX', label: strings.matrix, icon: CheckSquare },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as Tab)}
            className={`flex items-center gap-2 px-4 py-4 text-sm font-medium transition-all border-b-2 relative top-[2px] ${
              activeTab === tab.id 
                ? 'border-emerald-600 text-emerald-600 bg-emerald-50/50 rounded-t-lg' 
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50/50'
            }`}
          >
            <tab.icon size={16} /> {tab.label}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto bg-slate-50 p-6">
        <div className={`mx-auto bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden ${activeTab === 'MATRIX' ? 'max-w-[95vw]' : 'max-w-6xl'}`}>
          
          {activeTab === 'GENERAL' && (
            <div className="p-8 space-y-8 max-w-2xl">
              <div>
                <h3 className="text-lg font-semibold text-slate-800 mb-4 border-b pb-2">{strings.general}</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">{strings.projectName}</label>
                    <input 
                      value={project.name} 
                      onChange={e => updateProject({ name: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all font-medium text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">{strings.description}</label>
                    <textarea 
                      value={project.description} 
                      onChange={e => updateProject({ description: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all h-32 text-slate-700"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'FEATURES' && (
            <div className="p-8">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-lg font-semibold text-slate-800">{strings.definedFeatures}</h3>
                  <p className="text-sm text-slate-500">{strings.definedFeaturesDesc}</p>
                </div>
                <button onClick={addFeature} className="flex items-center gap-2 text-sm bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-slate-700 shadow-md transition-all">
                  <Plus size={16} /> {strings.addFeature}
                </button>
              </div>
              <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                {project.features.map((feature, fIdx) => (
                  <div key={feature.id} className="border border-slate-200 rounded-xl p-5 bg-white relative group hover:border-emerald-300 hover:shadow-md transition-all">
                    <button 
                      className="absolute top-3 right-3 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-red-50 rounded"
                      onClick={() => {
                        const newFeatures = project.features.filter(f => f.id !== feature.id);
                        setProject(p => ({ ...p, features: newFeatures }));
                      }}
                    >
                      <Trash2 size={16} />
                    </button>
                    
                    <div className="mb-4 space-y-2">
                       <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">{strings.featureName}</label>
                       <input 
                        value={feature.name}
                        onChange={(e) => {
                           const newFeatures = [...project.features];
                           newFeatures[fIdx].name = e.target.value;
                           setProject(p => ({ ...p, features: newFeatures }));
                        }}
                        className="font-bold text-lg text-slate-800 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-500 outline-none w-full pb-1"
                      />
                      <div className="flex items-center gap-2">
                         <ImageIcon size={14} className="text-slate-400" />
                         <input 
                           value={feature.imageUrl || ""}
                           onChange={(e) => {
                             const newFeatures = [...project.features];
                             newFeatures[fIdx].imageUrl = e.target.value;
                             setProject(p => ({ ...p, features: newFeatures }));
                           }}
                           className="text-xs flex-1 bg-slate-50 border border-slate-200 rounded px-2 py-1 outline-none focus:border-emerald-400"
                           placeholder={strings.imageURL}
                         />
                      </div>
                    </div>

                    <div className="space-y-2 pl-3 border-l-2 border-slate-100">
                       <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">{strings.states}</label>
                       {feature.states.map((state, sIdx) => (
                         <div key={state.id} className="flex items-center gap-2 group/state">
                            <div className="w-1.5 h-1.5 rounded-full bg-slate-300 group-focus-within/state:bg-emerald-400"></div>
                            <input 
                              value={state.label}
                              onChange={(e) => {
                                const newFeatures = [...project.features];
                                newFeatures[fIdx].states[sIdx].label = e.target.value;
                                setProject(p => ({ ...p, features: newFeatures }));
                              }}
                              className="text-sm bg-transparent outline-none w-full text-slate-600 focus:text-slate-900 focus:font-medium"
                            />
                            <button 
                              onClick={() => {
                                const newFeatures = [...project.features];
                                newFeatures[fIdx].states = newFeatures[fIdx].states.filter(s => s.id !== state.id);
                                setProject(p => ({ ...p, features: newFeatures }));
                              }}
                              className="text-slate-300 hover:text-red-400 opacity-0 group-hover/state:opacity-100 transition-opacity"
                            >
                              <X size={12} />
                            </button>
                         </div>
                       ))}
                       <button 
                         onClick={() => {
                           const newFeatures = [...project.features];
                           newFeatures[fIdx].states.push({ id: Math.random().toString(36).substr(2, 9), label: "..." });
                           setProject(p => ({ ...p, features: newFeatures }));
                         }}
                         className="text-xs text-emerald-600 hover:text-emerald-700 font-medium mt-3 flex items-center gap-1 bg-emerald-50 w-fit px-2 py-1 rounded"
                       >
                         <Plus size={10} /> {strings.addState}
                       </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'ENTITIES' && (
             <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-semibold text-slate-800">{strings.manageEntities}</h3>
                    <p className="text-sm text-slate-500">{strings.manageEntitiesDesc}</p>
                  </div>
                  <button onClick={addEntity} className="flex items-center gap-2 text-sm bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-slate-700 shadow-md transition-all">
                    <Plus size={16} /> {strings.addEntity}
                  </button>
                </div>
                <div className="space-y-4">
                  {project.entities.map((entity, eIdx) => (
                    <div key={entity.id} className="flex flex-col sm:flex-row gap-6 items-start border border-slate-200 p-6 rounded-xl bg-white hover:shadow-md transition-shadow">
                        <div className="w-full sm:w-48 space-y-2 flex-shrink-0">
                          <div className="aspect-[4/3] bg-slate-100 rounded-lg overflow-hidden border border-slate-200">
                            {entity.imageUrl ? (
                               <img src={entity.imageUrl} className="w-full h-full object-cover" alt="preview" />
                            ) : (
                               <div className="w-full h-full flex items-center justify-center text-slate-300">
                                 <ImageIcon size={32} />
                               </div>
                            )}
                          </div>
                          <input 
                             value={entity.imageUrl || ""}
                             onChange={(e) => {
                               const newEntities = [...project.entities];
                               newEntities[eIdx].imageUrl = e.target.value;
                               setProject(p => ({...p, entities: newEntities}));
                             }}
                             className="text-xs w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded outline-none focus:border-emerald-500 text-slate-600"
                             placeholder={strings.imageURL}
                           />
                        </div>

                        <div className="flex-1 space-y-4 w-full">
                           <div className="flex justify-between items-start">
                             <input 
                               value={entity.name}
                               onChange={(e) => {
                                 const newEntities = [...project.entities];
                                 newEntities[eIdx].name = e.target.value;
                                 setProject(p => ({...p, entities: newEntities}));
                               }}
                               className="text-xl font-bold bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-500 outline-none w-full pb-1 text-slate-800"
                             />
                             <button 
                              onClick={() => {
                                const newEntities = project.entities.filter(e => e.id !== entity.id);
                                setProject(p => ({...p, entities: newEntities}));
                              }}
                              className="text-slate-300 hover:text-red-500 p-2 hover:bg-red-50 rounded transition-colors"
                            >
                              <Trash2 size={18} />
                            </button>
                           </div>
                           <textarea 
                             value={entity.description}
                             onChange={(e) => {
                               const newEntities = [...project.entities];
                               newEntities[eIdx].description = e.target.value;
                               setProject(p => ({...p, entities: newEntities}));
                             }}
                             className="text-sm text-slate-600 bg-slate-50 border border-transparent focus:bg-white focus:border-emerald-500 w-full h-24 outline-none resize-none rounded-lg p-3 transition-colors"
                           />
                        </div>
                    </div>
                  ))}
                </div>
             </div>
          )}

          {activeTab === 'MATRIX' && (
            <div className="flex flex-col h-full bg-slate-50">
              <div className="p-4 border-b bg-white flex justify-between items-center">
                <h3 className="font-semibold text-slate-700">{strings.scoringMatrix}</h3>
                <span className="text-xs text-slate-400">{strings.scoringMatrixDesc}</span>
              </div>
              <div className="overflow-auto custom-scrollbar flex-1 relative">
                <div className="inline-block min-w-full align-top">
                  <div className="grid" style={{ 
                      gridTemplateColumns: `minmax(200px, 250px) repeat(${project.features.reduce((acc, f) => acc + f.states.length, 0)}, minmax(80px, 1fr))`
                    }}>
                    
                    {/* Header Row */}
                    <div className="sticky top-0 left-0 z-30 bg-slate-800 text-white p-4 font-bold border-r border-slate-700 shadow-md flex items-end">
                      {strings.taxaFeatures}
                    </div>
                    {project.features.map(feature => (
                      <div key={feature.id} className="sticky top-0 z-20 bg-slate-800 text-white border-r border-slate-700 shadow-md text-center" style={{ gridColumn: `span ${feature.states.length}`}}>
                        <div className="p-2 border-b border-slate-600 font-semibold truncate text-sm bg-slate-900/50">
                          {feature.name}
                        </div>
                        <div className="flex">
                           {feature.states.map(state => (
                             <div key={state.id} className="flex-1 p-2 text-xs text-slate-300 border-r border-slate-700 last:border-0 h-full flex items-center justify-center min-w-[80px]">
                               {state.label}
                             </div>
                           ))}
                        </div>
                      </div>
                    ))}

                    {/* Body Rows */}
                    {project.entities.map((entity, idx) => (
                      <React.Fragment key={entity.id}>
                        {/* Entity Name Column */}
                        <div className={`sticky left-0 z-10 bg-white p-3 border-r border-b border-slate-200 flex items-center gap-3 shadow-[4px_0_10px_-4px_rgba(0,0,0,0.1)] hover:bg-slate-50 group ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}>
                           <div className="w-8 h-8 rounded bg-slate-200 overflow-hidden flex-shrink-0">
                              {entity.imageUrl && <img src={entity.imageUrl} className="w-full h-full object-cover" />}
                           </div>
                           <span className="font-medium text-slate-700 text-sm group-hover:text-emerald-600 transition-colors">{entity.name}</span>
                        </div>

                        {/* Checkboxes */}
                        {project.features.map(feature => (
                          feature.states.map(state => {
                             const isChecked = entity.traits[feature.id]?.includes(state.id);
                             return (
                               <div key={`${entity.id}-${state.id}`} className={`border-b border-r border-slate-100 flex items-center justify-center p-2 hover:bg-emerald-50 transition-colors ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}>
                                 <button
                                    onClick={() => toggleTrait(entity.id, feature.id, state.id)}
                                    className={`w-8 h-8 rounded-md flex items-center justify-center transition-all duration-200 transform active:scale-95 ${
                                      isChecked 
                                        ? 'bg-emerald-600 text-white shadow-sm' 
                                        : 'bg-slate-100 text-slate-300 hover:bg-slate-200'
                                    }`}
                                  >
                                    {isChecked && <CheckSquare size={16} strokeWidth={3} />}
                                  </button>
                               </div>
                             );
                          })
                        ))}
                      </React.Fragment>
                    ))}

                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* AI Wizard Modal */}
      {showAiModal && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200 border border-slate-200 max-h-[90vh] flex flex-col">
             {/* Yellow/Gold Header */}
             <div className="bg-gradient-to-r from-amber-500 to-yellow-500 p-6 text-white shrink-0">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-white/20 rounded-lg">
                    <Brain size={24} className="text-white" />
                  </div>
                  <h3 className="text-2xl font-bold">{strings.aiTitle}</h3>
                </div>
                <p className="text-amber-50 text-sm font-medium drop-shadow-sm">
                  {strings.aiDesc}
                </p>
             </div>
             
             <div className="p-6 space-y-5 overflow-y-auto custom-scrollbar">
                <div>
                   <label className="block text-sm font-semibold text-slate-700 mb-1.5">{strings.topic}</label>
                   <input 
                      value={aiConfig.topic}
                      onChange={(e) => setAiConfig(prev => ({...prev, topic: e.target.value}))}
                      placeholder={strings.topicPlace}
                      className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-lg"
                      disabled={isGenerating}
                   />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                     <label className="block text-xs font-semibold text-slate-500 uppercase mb-1.5">{strings.geography}</label>
                     <input 
                        value={aiConfig.geography}
                        onChange={(e) => setAiConfig(prev => ({...prev, geography: e.target.value}))}
                        placeholder="e.g. Amazon Rainforest"
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none text-sm"
                        disabled={isGenerating}
                     />
                  </div>
                  <div>
                     <label className="block text-xs font-semibold text-slate-500 uppercase mb-1.5">{strings.taxonomy}</label>
                     <input 
                        value={aiConfig.taxonomy}
                        onChange={(e) => setAiConfig(prev => ({...prev, taxonomy: e.target.value}))}
                        placeholder="e.g. Family: Felidae"
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none text-sm"
                        disabled={isGenerating}
                     />
                  </div>
                </div>

                {/* Focus Selector */}
                <div>
                   <label className="block text-xs font-semibold text-slate-500 uppercase mb-2">{strings.featureFocus}</label>
                   <div className="flex bg-slate-100 p-1 rounded-lg">
                      {(['general', 'reproductive', 'vegetative'] as FeatureFocus[]).map(focus => (
                        <button
                          key={focus}
                          onClick={() => setAiConfig(prev => ({...prev, featureFocus: focus}))}
                          className={`flex-1 py-2 rounded-md text-xs font-medium transition-all ${
                             aiConfig.featureFocus === focus 
                               ? 'bg-white text-amber-600 shadow-sm' 
                               : 'text-slate-500 hover:text-slate-800'
                          }`}
                          disabled={isGenerating}
                        >
                           {focus === 'general' ? strings.focusGeneral : focus === 'reproductive' ? strings.focusRepro : strings.focusVeg}
                        </button>
                      ))}
                   </div>
                </div>

                {/* Sliders */}
                <div className="space-y-4">
                  <div>
                     <div className="flex justify-between items-center mb-1.5">
                        <label className="block text-xs font-semibold text-slate-500 uppercase">{strings.numEntities}</label>
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">{aiConfig.count}</span>
                     </div>
                     <input 
                        type="range"
                        min="3"
                        max="30"
                        step="1"
                        value={aiConfig.count}
                        onChange={(e) => setAiConfig(prev => ({...prev, count: parseInt(e.target.value)}))}
                        className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-500"
                        disabled={isGenerating}
                     />
                  </div>

                  <div>
                     <div className="flex justify-between items-center mb-1.5">
                        <label className="block text-xs font-semibold text-slate-500 uppercase">{strings.numFeatures}</label>
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">{aiConfig.featureCount}</span>
                     </div>
                     <input 
                        type="range"
                        min="2"
                        max="10"
                        step="1"
                        value={aiConfig.featureCount}
                        onChange={(e) => setAiConfig(prev => ({...prev, featureCount: parseInt(e.target.value)}))}
                        className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-500"
                        disabled={isGenerating}
                     />
                  </div>
                </div>

                {/* Image Toggles */}
                <div className="space-y-3 pt-2 border-t border-slate-100">
                    <label className="flex items-center justify-between cursor-pointer group">
                       <div className="flex items-center gap-2">
                          <ImageIcon size={16} className="text-slate-400 group-hover:text-amber-500 transition-colors" />
                          <span className="text-sm font-medium text-slate-700">{strings.fetchSpeciesImg}</span>
                       </div>
                       <div className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${aiConfig.includeSpeciesImages ? 'bg-amber-500' : 'bg-slate-300'}`}>
                          <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${aiConfig.includeSpeciesImages ? 'translate-x-5' : ''}`}></div>
                       </div>
                       <input 
                          type="checkbox" 
                          className="hidden" 
                          checked={aiConfig.includeSpeciesImages}
                          onChange={(e) => setAiConfig(prev => ({...prev, includeSpeciesImages: e.target.checked}))}
                          disabled={isGenerating}
                        />
                    </label>

                    <label className="flex items-center justify-between cursor-pointer group">
                       <div className="flex items-center gap-2">
                          <Settings2 size={16} className="text-slate-400 group-hover:text-amber-500 transition-colors" />
                          <span className="text-sm font-medium text-slate-700">{strings.fetchFeatureImg}</span>
                       </div>
                       <div className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${aiConfig.includeFeatureImages ? 'bg-amber-500' : 'bg-slate-300'}`}>
                          <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${aiConfig.includeFeatureImages ? 'translate-x-5' : ''}`}></div>
                       </div>
                       <input 
                          type="checkbox" 
                          className="hidden" 
                          checked={aiConfig.includeFeatureImages}
                          onChange={(e) => setAiConfig(prev => ({...prev, includeFeatureImages: e.target.checked}))}
                          disabled={isGenerating}
                        />
                    </label>
                </div>
                
                {isGenerating && (
                  <div className="bg-amber-50 text-amber-700 p-3 rounded-lg text-sm flex items-center justify-center gap-2">
                    <Loader2 className="animate-spin" size={16} /> {strings.generating}
                  </div>
                )}
             </div>

             <div className="p-4 bg-slate-50 border-t flex gap-3 shrink-0">
               <button 
                 onClick={() => setShowAiModal(false)}
                 className="flex-1 py-2.5 text-slate-600 font-medium hover:bg-slate-200 rounded-xl transition-colors"
                 disabled={isGenerating}
               >
                 {strings.cancel}
               </button>
               <button 
                 onClick={handleAiGenerate}
                 className="flex-1 py-2.5 bg-amber-500 text-white font-bold rounded-xl hover:bg-amber-600 shadow-lg shadow-amber-900/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                 disabled={isGenerating || !aiConfig.topic}
               >
                 {strings.generate}
               </button>
             </div>
          </div>
        </div>
      )}

      {/* Load Project Modal (Global) */}
      {showLoadModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
           <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95">
              <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                 <FolderOpen className="text-emerald-600" size={20} />
                 {strings.openSaved}
              </h3>
              <div className="space-y-2 max-h-64 overflow-y-auto mb-4 custom-scrollbar">
                 {savedProjects.length === 0 ? (
                   <p className="text-slate-500 text-sm text-center py-8 border-2 border-dashed border-slate-200 rounded-lg">{strings.noSaved}</p>
                 ) : (
                   savedProjects.map(p => (
                     <button 
                       key={p.id}
                       onClick={() => loadFromLocal(p)}
                       className="w-full text-left p-3 hover:bg-emerald-50 rounded-lg border border-slate-100 hover:border-emerald-200 group transition-all"
                     >
                        <div className="font-medium text-slate-800 group-hover:text-emerald-700">{p.name}</div>
                        <div className="text-xs text-slate-400 truncate">{p.description || "No description"}</div>
                     </button>
                   ))
                 )}
              </div>
              <button 
                onClick={() => setShowLoadModal(false)}
                className="w-full py-2.5 bg-slate-100 text-slate-600 rounded-xl font-medium hover:bg-slate-200 transition-colors"
              >
                {strings.close}
              </button>
           </div>
        </div>
      )}
    </div>
  );
};