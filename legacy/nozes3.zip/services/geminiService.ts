import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Project, Entity, Feature, AIConfig } from "../types";

// Helper to generate IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

export const generateKeyFromTopic = async (config: AIConfig): Promise<Project> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const langInstruction = config.language === 'pt' 
    ? "All content (Project Name, Description, Features, States, Entities, Descriptions) MUST be in Portuguese (Brazil)."
    : "All content must be in English.";

  // Common Schema Definitions
  const baseFeatureSchema = {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING, description: "Name of the feature (e.g., 'Wing Color')" },
      imageUrl: { type: Type.STRING, description: "URL for feature illustration" },
      states: {
        type: Type.ARRAY,
        items: { type: Type.STRING, description: "A state description (e.g., 'Blue')" }
      }
    },
    required: ["name", "states"]
  };

  // 1. IMPORT MODE LOGIC
  if (config.importedFile) {
    const importSystemInstruction = `
      You are an expert biologist and data analyst.
      Your task is to analyze the provided document (PDF, Text, or Image) which contains biological identification data (dichotomous key, species descriptions, or a table).
      
      **Goal**: Extract a structured Matrix Identification Key from the document.
      
      **CRITICAL**: 
      1. You must extract **EVERY SINGLE** species/entity found in the text. 
      2. **DO NOT LIMIT** to 30. If there are 133 species, extract 133.
      3. Be concise with descriptions to fit all data.
      
      **Instructions**:
      1. Identify all distinct 'Entities' (Species, Genera, etc.) mentioned.
      2. Identify the 'Features' (morphological characteristics) used to distinguish them.
      3. Create 'States' for each feature.
      4. Build a Matrix: For every entity, list its traits.
      5. ${langInstruction}
      
      **Format**: Return valid JSON. Use the "Feature: State" string format for traits to save space.
    `;

    const importPrompt = `
      Analyze the attached file. Extract a comprehensive biological identification key.
      
      - Project Name: Derive from document title.
      - Description: Summary of content.
      - Entities: Extract ALL entities found. Do not truncate the list.
      - Features: Extract distinctive traits.
      - Matrix: Map traits to entities.
      
      If analyzing a Dichotomous Key, flatten the logic: assign all traits accumulated along the path to the species.
    `;

    // Optimized Schema for Import (Uses string array for traits to save tokens on large lists)
    const importSchema: Schema = {
      type: Type.OBJECT,
      properties: {
        projectName: { type: Type.STRING },
        projectDescription: { type: Type.STRING },
        features: {
          type: Type.ARRAY,
          items: baseFeatureSchema
        },
        entities: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              imageUrl: { type: Type.STRING, description: "URL if found, else empty." },
              // Optimization: Use array of strings "FeatureName: StateValue" instead of objects to save tokens
              traits: {
                type: Type.ARRAY,
                items: { type: Type.STRING, description: "Format: 'Feature Name: State Value'" }
              }
            },
            required: ["name", "description", "traits"]
          }
        }
      },
      required: ["projectName", "projectDescription", "features", "entities"]
    };

    const parts = [
      {
        inlineData: {
          mimeType: config.importedFile.mimeType,
          data: config.importedFile.data
        }
      },
      { text: importPrompt }
    ];

    return await callGemini(ai, config.model, parts, importSystemInstruction, importSchema);
  }

  // 2. GENERATION MODE LOGIC (Standard)
  let focusInstruction = "";
  if (config.featureFocus === 'reproductive') {
    focusInstruction = "Focus primarily on reproductive features (e.g., flowers, fruits, seeds, cones, spores, inflorescence).";
  } else if (config.featureFocus === 'vegetative') {
    focusInstruction = "Focus primarily on vegetative features (e.g., leaves, bark, stem, roots, growth habit, phyllo taxis).";
  } else {
    focusInstruction = "Use a balanced mix of vegetative and reproductive features.";
  }

  // Detail Level Logic
  let detailInstruction = "";
  if (config.detailLevel === 1) {
    detailInstruction = "AUDIENCE: Children or General Public. Use simple, common language. Short descriptions. Avoid complex jargon.";
  } else if (config.detailLevel === 3) {
    detailInstruction = "AUDIENCE: Experts/Scientists. Use precise botanical/zoological terminology. Comprehensive descriptions. High detail.";
  } else {
    detailInstruction = "AUDIENCE: Students/Enthusiasts. Balanced use of scientific terms with clear explanations.";
  }

  let speciesImageInstruction = config.includeSpeciesImages 
    ? "For each entity, try to provide a high-probability Wikimedia Commons URL. If reasonably sure, include it."
    : "Leave `imageUrl` empty for entities.";

  let featureImageInstruction = config.includeFeatureImages
    ? "For each feature, try to provide a generic illustrative image URL. If unsure, return an empty string."
    : "Leave `imageUrl` empty for features.";

  const systemInstruction = `
    You are an expert taxonomist and biologist. 
    Your task is to create an interactive identification key (matrix key) based strictly on the user's constraints.
    
    Constraints:
    1.  **Language**: ${langInstruction}
    2.  **Topic**: The general subject.
    3.  **Geography**: Restrict entities to this region/biome.
    4.  **Taxonomy**: Restrict to this Family/Genus/Order if specified.
    5.  **Quantity**: Generate exactly or close to the requested number of entities and features.
    6.  **Focus**: ${focusInstruction}
    7.  **Detail Level**: ${detailInstruction}
    8.  **Images**: 
        - Species: ${speciesImageInstruction}
        - Features: ${featureImageInstruction}

    Output Requirements:
    1.  List of distinctive features. Each feature must have 2+ states.
    2.  List of entities.
    3.  Matrix: Assign correct states.
    4.  **Scientific Accuracy**: Ensure traits are factual.

    The response must be a structured JSON object.
  `;

  const prompt = `
    Create an identification key for: "${config.topic}".
    
    Constraints:
    - Language: ${config.language === 'pt' ? 'Portuguese' : 'English'}
    - Geographic Scope: ${config.geography || "Global"}
    - Taxonomic Context: ${config.taxonomy || "General"}
    - Target Number of Entities: ${config.count}
    - Target Number of Features: ${config.featureCount}
    - Feature Focus: ${config.featureFocus}
    - Complexity Level: ${config.detailLevel}/3

    Ensure the features allow for effective separation of these entities.
  `;

  // Standard Schema (Verbose/Strict for Generation)
  const generationSchema: Schema = {
    type: Type.OBJECT,
    properties: {
      projectName: { type: Type.STRING },
      projectDescription: { type: Type.STRING },
      features: {
        type: Type.ARRAY,
        items: baseFeatureSchema
      },
      entities: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            description: { type: Type.STRING },
            imageUrl: { type: Type.STRING, description: "URL for species image." },
            traits: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  featureName: { type: Type.STRING, description: "Must match one of the feature names exactly" },
                  stateValue: { type: Type.STRING, description: "Must match one of the state values for that feature exactly" }
                }
              }
            }
          },
          required: ["name", "description", "traits"]
        }
      }
    },
    required: ["projectName", "projectDescription", "features", "entities"]
  };

  return await callGemini(ai, config.model, prompt, systemInstruction, generationSchema);
};

// Unified Gemini Call function with Schema support
async function callGemini(
  ai: GoogleGenAI, 
  modelName: string, 
  contents: any, 
  systemInstruction: string,
  responseSchema: Schema
): Promise<Project> {
  
  const generateContentWithFallback = async (currentModel: string): Promise<any> => {
    try {
      return await ai.models.generateContent({
        model: currentModel.trim(),
        contents: contents,
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: "application/json",
          responseSchema: responseSchema
        }
      });
    } catch (error: any) {
      if (error.message?.includes("404") || error.message?.includes("NOT_FOUND")) {
        const fallbackModel = "gemini-2.5-flash";
        if (currentModel !== fallbackModel) {
           console.warn(`Model ${currentModel} not found, falling back to ${fallbackModel}`);
           return await generateContentWithFallback(fallbackModel);
        }
      }
      throw error;
    }
  };

  try {
    const modelToUse = modelName || "gemini-2.5-flash";
    const response = await generateContentWithFallback(modelToUse);
    const data = JSON.parse(response.text || "{}");
    
    if (!data.projectName) throw new Error("Invalid AI response");

    // Transform AI response to internal data model with IDs
    const features: Feature[] = data.features.map((f: any) => ({
      id: generateId(),
      name: f.name,
      imageUrl: f.imageUrl || "", 
      states: f.states.map((s: string) => ({ id: generateId(), label: s }))
    }));

    const entities: Entity[] = data.entities.map((e: any) => {
      const entityTraits: Record<string, string[]> = {};
      
      e.traits.forEach((t: any) => {
        let fName: string = "";
        let sValue: string = "";

        // Hybrid Parsing: Support both Object {featureName, stateValue} and String "Feature:State"
        if (typeof t === 'string') {
          const splitIndex = t.indexOf(':');
          if (splitIndex > -1) {
            fName = t.substring(0, splitIndex).trim();
            sValue = t.substring(splitIndex + 1).trim();
          }
        } else if (typeof t === 'object' && t !== null) {
          fName = t.featureName;
          sValue = t.stateValue;
        }

        if (fName && sValue) {
          // Fuzzy match feature name to be robust against minor AI hallucinations (case/trim)
          const feature = features.find(f => f.name.toLowerCase() === fName.toLowerCase());
          if (feature) {
            // Fuzzy match state
            const state = feature.states.find(s => s.label.toLowerCase() === sValue.toLowerCase());
            if (state) {
              if (!entityTraits[feature.id]) entityTraits[feature.id] = [];
              entityTraits[feature.id].push(state.id);
            }
          }
        }
      });

      // Simple URL validation
      const rawUrl = e.imageUrl ? e.imageUrl.trim() : "";
      const isValidUrl = rawUrl.startsWith("http");

      return {
        id: generateId(),
        name: e.name,
        description: e.description,
        imageUrl: isValidUrl ? rawUrl : `https://picsum.photos/seed/${encodeURIComponent(e.name)}/400/300`,
        traits: entityTraits
      };
    });

    return {
      id: generateId(),
      name: data.projectName,
      description: data.projectDescription,
      features,
      entities
    };

  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
}