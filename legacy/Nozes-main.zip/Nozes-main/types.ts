export type Language = 'en' | 'pt';

export type FeatureFocus = 'general' | 'reproductive' | 'vegetative';

export interface FeatureState {
  id: string;
  label: string;
}

export interface Feature {
  id: string;
  name: string;
  imageUrl?: string;
  states: FeatureState[];
}

export interface Entity {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;
  // Map featureId to an array of valid stateIds for this entity
  traits: Record<string, string[]>; 
}

export interface Project {
  id: string;
  name: string;
  description: string;
  features: Feature[];
  entities: Entity[];
}

export interface AIConfig {
  topic: string;
  count: number;
  featureCount: number;
  geography: string;
  taxonomy: string;
  language: Language;
  featureFocus: FeatureFocus;
  includeSpeciesImages: boolean;
  includeFeatureImages: boolean;
  model: string;
}

export type ViewMode = 'HOME' | 'BUILDER' | 'PLAYER';

export interface GenerationRequest {
  topic: string;
  context?: string;
}